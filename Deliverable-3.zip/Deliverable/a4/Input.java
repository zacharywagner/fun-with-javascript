package a4;

//struct
public class Input 
{
    public static boolean w;
    public static boolean a;    
    public static boolean s;
    public static boolean d; 
    public static boolean q;
    public static boolean e; 
    public static boolean up;
    public static boolean down; 
    public static boolean left;
    public static boolean right;
    
    public static int mousePositionX;
	public static int mousePositionY;
    public static int mouseWheelPosition;

    public static void reset()
    {
        w = a = s = d = q = e = up = down = left = right = false;
    }
}
