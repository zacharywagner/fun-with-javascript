package a4;

public class Time 
{
    public static float delta;
    public static float total;

    private static long start;
    private static long current;

    public static void init()
    {
        start = System.currentTimeMillis();
    }

    public static void update()
    {
        long previous = current;
        current = System.currentTimeMillis();
        delta = (float)(current - previous) / 1000f;
        total = (float)(current - start) / 1000f;
    }
}
