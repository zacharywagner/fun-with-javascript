package a4;

//
// Import
//
//#region
import com.jogamp.common.nio.Buffers;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import static com.jogamp.opengl.GL4.*;
import com.jogamp.opengl.util.*;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.lang.Math;
import javax.swing.JFrame;
import java.awt.Color; 

//#endregion

//
// Starter
//
//#region

//https://opengameart.org/content/space-scout-ship
//CC-BY 4.0

public class Starter extends JFrame implements GLEventListener, KeyListener, WindowFocusListener, MouseMotionListener, MouseWheelListener
{
    //====================================================================================================
    // Variable Declaration
    //====================================================================================================
    //#region
    private GLCanvas glCanvas;
    private int renderingProgram0, renderingProgram1, renderingProgram2, renderingProgram3, renderingProgram4, renderingProgram5;
    private int vao[] = new int[1];
    private int vbo[] = new int[14];
    private FloatBuffer floatBuffer = Buffers.newDirectFloatBuffer(16);
    private int mvLoc, pLoc, nLoc, globAmbLoc, ambLoc, difLoc, specLoc, posLoc, matAmbLoc, matDifLoc, matSpecLoc, matShiLoc, sLoc, vLoc, fLoc, alphaLoc, flipLoc;

    //Declare each-and-every model and texture variable here!
    private ImportedModel model0, model1, model2;
    private Matrix4f mMat1 = new Matrix4f();
    private Matrix4f mMat2 = new Matrix4f();
    private Matrix4f mMat3 = new Matrix4f();
    private Matrix4f mMat4 = new Matrix4f();
    private Matrix4f mMat5 = new Matrix4f();
    private Matrix4f mMat6 = new Matrix4f();
    private int texture0, texture1, texture2;

    //Declare each-and-every camera variable here!
    private Camera camera;

    //Declare each-and-every light and material variable here!
    private Matrix4f lPMat = new Matrix4f();
    private Matrix4f lVMat = new Matrix4f();
    private float[] globalAmbient = new float[] { 0.5f, 0.5f, 0.5f, 1.0f };
    private Vector3f lightPosition = new Vector3f();
	private float[] lightAmbient = new float[] { 0.1f, 0.1f, 0.1f, 1.0f };
	private float[] lightDiffuse = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
	private float[] lightSpecular = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };

    float[] materialAmbient0 = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
	float[] materialDiffuse0 = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
	float[] materialSpecular0 = new float[] { 0.3f, 0.3f, 0.3f, 1.0f };
	float materialShine0 = 12.0f;

    float[] materialAmbient1 = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
	float[] materialDiffuse1 = new float[] { 0.8f, 0.8f, 0.8f, 1.0f };
	float[] materialSpecular1 = new float[] { 0.8f, 0.8f, 0.8f, 1.0f };
	float materialShine1 = 1.0f;

    //Declare each-and-every shadow map variable here!
    private Matrix4f sMVPMat1 = new Matrix4f();
    private Matrix4f sMVPMat2 = new Matrix4f();
    private int[] shadowBuffer = new int[1];
    private int[] shadowTexture = new int[1];
    private Matrix4f bMat = new Matrix4f();

    //Declare each-and-every cube map variable here!
    private int cubeMap;

    //Declare each-and-every fog and blending/transparency variable here!
    private float fog;

    //Declare each-and-every perlin noise variable here!
    private int noiseTexture;
	private int noiseHeight= 300;
	private int noiseWidth = 300;
	private int noiseDepth = 300;
	private double[][][] noise = new double[noiseWidth][noiseHeight][noiseDepth];
	private java.util.Random random = new java.util.Random();

    //Declare each-and-every geometry shader variable here!
    private int renderingProgram6;

    //Declare each-and-every normal map variable here!
    private int renderingProgram7;
    private Sphere model3 = new Sphere(64);
    private int model3VertexCount;
    private int texture4;
    private int normalMap;

    //OTHER
    private int renderingProgram8, renderingProgram9;
    private boolean renderGizmo = true;
    private boolean lightSwitch = true;
    private boolean control = false;

    //#endregion

    //====================================================================================================
    // GLEventListener Implementation
    //====================================================================================================
    public void init(GLAutoDrawable drawable)
    {
        GL4 gl = (GL4)GLContext.getCurrentGL();
        renderingProgram0 = Utils.createShaderProgram("a4/vertShader0.glsl", "a4/fragShader0.glsl");
        renderingProgram1 = Utils.createShaderProgram("a4/vertShader1.glsl", "a4/fragShader1.glsl");
        renderingProgram2 = Utils.createShaderProgram("a4/vertShader2.glsl", "a4/fragShader2.glsl");
        renderingProgram3 = Utils.createShaderProgram("a4/vertShader3.glsl", "a4/fragShader3.glsl");
        renderingProgram4 = Utils.createShaderProgram("a4/vertShader4.glsl", "a4/fragShader4.glsl");
        gl.glGenVertexArrays(vao.length, vao, 0);
		gl.glBindVertexArray(vao[0]);
		gl.glGenBuffers(vbo.length, vbo, 0);
        camera = new Camera(new Vector3f(0f, 0f, -32f), 0f, 0f);
        Time.init();
        initPerlinNoise(gl);
        initScene(gl);
        initEnvironmentMapping(gl);
        initCubeMap(gl);
        initShadowMap(gl);
        fog = 0f;
        initGeometryShader(gl);
        initNormalMap(gl);

        renderingProgram8 = Utils.createShaderProgram("a4/vertShader8.glsl", "a4/fragShader9.glsl");
        renderingProgram9 = Utils.createShaderProgram("a4/vertShader9.glsl", "a4/fragShader9.glsl");
    }
    
    private void initScene(GL4 gl)
    {
        model0 = new ImportedModel("model0.obj");
        int vertexCount1 = model0.getNumVertices();
        Vector3f[] importedModelVertexArray1 = model0.getVertices();
		Vector2f[] importedModelTextureArray1 = model0.getTexCoords();
		Vector3f[] importedModelNormalArray1 = model0.getNormals();
		float[] vertexArray1 = new float[vertexCount1 * 3];
		float[] textureArray1 = new float[vertexCount1 * 2];
		float[] normalArray1 = new float[vertexCount1 * 3];
		for(int i = 0; i < vertexCount1; i++)
		{
			vertexArray1[i * 3] = (float)(importedModelVertexArray1[i].x);
			vertexArray1[i * 3 + 1] = (float)(importedModelVertexArray1[i].y);
			vertexArray1[i * 3 + 2] = (float)(importedModelVertexArray1[i].z);
			textureArray1[i * 2] = (float)(importedModelTextureArray1[i].x);
			textureArray1[i * 2 + 1] = (float)(importedModelTextureArray1[i].y);
			normalArray1[i * 3] = (float)(importedModelNormalArray1[i].x);
			normalArray1[i * 3 + 1] = (float)(importedModelNormalArray1[i].y);
			normalArray1[i * 3 + 2] = (float)(importedModelNormalArray1[i].z);
		}

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		FloatBuffer vertexBuffer = Buffers.newDirectFloatBuffer(vertexArray1);
		gl.glBufferData(GL_ARRAY_BUFFER, vertexBuffer.limit() * 4, vertexBuffer, GL_STATIC_DRAW);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
		FloatBuffer textureBuffer = Buffers.newDirectFloatBuffer(textureArray1);
		gl.glBufferData(GL_ARRAY_BUFFER, textureBuffer.limit() * 4, textureBuffer, GL_STATIC_DRAW);
		texture0 = Utils.loadTexture("a4/texture0.png");

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		FloatBuffer normalBuffer = Buffers.newDirectFloatBuffer(normalArray1);
		gl.glBufferData(GL_ARRAY_BUFFER, normalBuffer.limit() * 4, normalBuffer, GL_STATIC_DRAW);

        model1 = new ImportedModel("model1.obj");		
		int vertexCount2 = model1.getNumVertices();
		Vector3f[] importedModelVertexArray2 = model1.getVertices();
		Vector2f[] importedModelTextureArray2 = model1.getTexCoords();
		Vector3f[] importedModelNormalArray2 = model1.getNormals();
		float[] vertexArray2 = new float[vertexCount2 * 3];
		float[] textureArray2 = new float[vertexCount2 * 2];
		float[] normalArray2 = new float[vertexCount2 * 3];
		for(int i = 0; i < vertexCount2; i++)
		{
			vertexArray2[i * 3] = (float)(importedModelVertexArray2[i].x);
			vertexArray2[i * 3 + 1] = (float)(importedModelVertexArray2[i].y);
			vertexArray2[i * 3 + 2] = (float)(importedModelVertexArray2[i].z);
			textureArray2[i * 2] = (float)(importedModelTextureArray2[i].x);
			textureArray2[i * 2 + 1] = (float)(importedModelTextureArray2[i].y);
			normalArray2[i * 3] = (float)(importedModelNormalArray2[i].x);
			normalArray2[i * 3 + 1] = (float)(importedModelNormalArray2[i].y);
			normalArray2[i * 3 + 2] = (float)(importedModelNormalArray2[i].z);
		}

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
		FloatBuffer vertexBuffer2 = Buffers.newDirectFloatBuffer(vertexArray2);
		gl.glBufferData(GL_ARRAY_BUFFER, vertexBuffer2.limit() * 4, vertexBuffer2, GL_STATIC_DRAW);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
		FloatBuffer textureBuffer2 = Buffers.newDirectFloatBuffer(textureArray2);
		gl.glBufferData(GL_ARRAY_BUFFER, textureBuffer2.limit() * 4, textureBuffer2, GL_STATIC_DRAW);
		texture1 = Utils.loadTexture("a4/texture1.png");

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
		FloatBuffer normalBuffer2 = Buffers.newDirectFloatBuffer(normalArray2);
		gl.glBufferData(GL_ARRAY_BUFFER, normalBuffer2.limit() * 4, normalBuffer2, GL_STATIC_DRAW);
    }

    private void initCubeMap(GL4 gl)
    {
        renderingProgram0 = Utils.createShaderProgram("a4/vertShader0.glsl", "a4/fragShader0.glsl");
        cubeMap = Utils.loadCubeMap("a4/cubeMap");
        float[] cubeMapVertexArray =
		{	-1.0f,  1.0f, -1.0f, -1.0f, -1.0f, -1.0f, 1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f, 1.0f,  1.0f, -1.0f, -1.0f,  1.0f, -1.0f,
			1.0f, -1.0f, -1.0f, 1.0f, -1.0f,  1.0f, 1.0f,  1.0f, -1.0f,
			1.0f, -1.0f,  1.0f, 1.0f,  1.0f,  1.0f, 1.0f,  1.0f, -1.0f,
			1.0f, -1.0f,  1.0f, -1.0f, -1.0f,  1.0f, 1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f,  1.0f, -1.0f,  1.0f,  1.0f, 1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f,  1.0f, -1.0f, -1.0f, -1.0f, -1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f, -1.0f, -1.0f,  1.0f, -1.0f, -1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f,  1.0f,  1.0f, -1.0f,  1.0f,  1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f,  1.0f,
			-1.0f,  1.0f, -1.0f, 1.0f,  1.0f, -1.0f, 1.0f,  1.0f,  1.0f,
			1.0f,  1.0f,  1.0f, -1.0f,  1.0f,  1.0f, -1.0f,  1.0f, -1.0f
		};
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
		FloatBuffer floatBuffer = Buffers.newDirectFloatBuffer(cubeMapVertexArray);
		gl.glBufferData(GL_ARRAY_BUFFER, floatBuffer.limit()*4, floatBuffer, GL_STATIC_DRAW);
        gl.glEnable(GL_TEXTURE_CUBE_MAP_SEAMLESS);
    }
    
    private void initShadowMap(GL4 gl)
    {
        gl.glGenFramebuffers(1, shadowBuffer, 0);
	
		gl.glGenTextures(1, shadowTexture, 0);
		gl.glBindTexture(GL_TEXTURE_2D, shadowTexture[0]);
		gl.glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32, glCanvas.getWidth(), glCanvas.getHeight(), 0, GL_DEPTH_COMPONENT, GL_FLOAT, null);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
		
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }
   
    private void initEnvironmentMapping(GL4 gl)
    {
        renderingProgram5 = Utils.createShaderProgram("a4/vertShader5.glsl", "a4/fragShader5.glsl");
        model2 = new ImportedModel("model2.obj");
        int vertexCount1 = model2.getNumVertices();
        Vector3f[] importedModelVertexArray1 = model2.getVertices();
		Vector2f[] importedModelTextureArray1 = model2.getTexCoords();
		Vector3f[] importedModelNormalArray1 = model2.getNormals();
		float[] vertexArray1 = new float[vertexCount1 * 3];
		float[] textureArray1 = new float[vertexCount1 * 2];
		float[] normalArray1 = new float[vertexCount1 * 3];
		for(int i = 0; i < vertexCount1; i++)
		{
			vertexArray1[i * 3] = (float)(importedModelVertexArray1[i].x);
			vertexArray1[i * 3 + 1] = (float)(importedModelVertexArray1[i].y);
			vertexArray1[i * 3 + 2] = (float)(importedModelVertexArray1[i].z);
			textureArray1[i * 2] = (float)(importedModelTextureArray1[i].x);
			textureArray1[i * 2 + 1] = (float)(importedModelTextureArray1[i].y);
			normalArray1[i * 3] = (float)(importedModelNormalArray1[i].x);
			normalArray1[i * 3 + 1] = (float)(importedModelNormalArray1[i].y);
			normalArray1[i * 3 + 2] = (float)(importedModelNormalArray1[i].z);
		}

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[7]);
		FloatBuffer vertexBuffer = Buffers.newDirectFloatBuffer(vertexArray1);
		gl.glBufferData(GL_ARRAY_BUFFER, vertexBuffer.limit() * 4, vertexBuffer, GL_STATIC_DRAW);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
		FloatBuffer textureBuffer = Buffers.newDirectFloatBuffer(textureArray1);
		gl.glBufferData(GL_ARRAY_BUFFER, textureBuffer.limit() * 4, textureBuffer, GL_STATIC_DRAW);
		texture2 = Utils.loadTexture("a4/texture2.png");

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
		FloatBuffer normalBuffer = Buffers.newDirectFloatBuffer(normalArray1);
		gl.glBufferData(GL_ARRAY_BUFFER, normalBuffer.limit() * 4, normalBuffer, GL_STATIC_DRAW);
    }



    private void initPerlinNoise(GL4 gl)
    {
        generateNoise();
        byte[] byteArray = new byte[noiseHeight * noiseWidth * noiseDepth * 4];
        initDataArray(byteArray);
        ByteBuffer bb = Buffers.newDirectByteBuffer(byteArray);

		int[] textureIDs = new int[1];
		gl.glGenTextures(1, textureIDs, 0);
		int textureID = textureIDs[0];

		gl.glBindTexture(GL_TEXTURE_3D, textureID);

		gl.glTexStorage3D(GL_TEXTURE_3D, 1, GL_RGBA8, noiseWidth, noiseHeight, noiseDepth);
		gl.glTexSubImage3D(GL_TEXTURE_3D, 0, 0, 0, 0, noiseWidth, noiseHeight, noiseDepth, GL_RGBA, GL_UNSIGNED_INT_8_8_8_8_REV, bb);
		
		gl.glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

		noiseTexture = textureID;
    }

    private void initDataArray(byte byteArray[])
    {
        double frequency = 3;
        double power = 12;
        double size = 64;
        for(int i = 0; i < noiseWidth; i++)
        {
            for(int j = 0; j < noiseHeight; j++)
            {
                for(int k = 0; k < noiseDepth; k++)
                {
                    double xyz = (float)i / noiseWidth + (float)j / noiseHeight + (float)k / noiseDepth + power * turbulence(i, j, k, size) / 256f;
                    double sine = logistic(Math.abs(Math.sin(xyz * Math.PI * frequency)));
                    sine = Math.max(-1.0, Math.min(sine * 1.25 - .2, 1.0));
                    Color color = new Color((float)sine, (float)Math.min(sine*1.5-0.25, 1.0), (float)sine);
                    byteArray[i * (noiseWidth * noiseHeight * 4) + j * (noiseHeight * 4) + k * 4] = (byte)color.getRed();
                    byteArray[i * (noiseWidth * noiseHeight * 4) + j * (noiseHeight * 4) + k * 4 + 1] = (byte)color.getGreen();
                    byteArray[i * (noiseWidth * noiseHeight * 4) + j * (noiseHeight * 4) + k * 4 + 2] = (byte)color.getBlue();
                    byteArray[i * (noiseWidth * noiseHeight * 4) + j * (noiseHeight * 4) + k * 4 + 3] = (byte)255;
                }
            }
        }
    }

	private void generateNoise()
	{	for (int x=0; x<noiseWidth; x++)
		{	for (int y=0; y<noiseHeight; y++)
			{	for (int z=0; z<noiseDepth; z++)
				{	noise[x][y][z] = random.nextDouble();
	}	}	}	}
	
	private double smoothNoise(double x1, double y1, double z1)
	{	//get fractional part of x, y, and z
		double fractX = x1 - (int) x1;
		double fractY = y1 - (int) y1;
		double fractZ = z1 - (int) z1;

		//neighbor values
		int x2 = ((int)x1 + noiseWidth + 1) % noiseWidth;
		int y2 = ((int)y1 + noiseHeight+ 1) % noiseHeight;
		int z2 = ((int)z1 + noiseDepth + 1) % noiseDepth;

		//smooth the noise by interpolating
		double value = 0.0;
		value += (1-fractX) * (1-fractY) * (1-fractZ) * noise[(int)x1][(int)y1][(int)z1];
		value += (1-fractX) * fractY     * (1-fractZ) * noise[(int)x1][(int)y2][(int)z1];
		value += fractX     * (1-fractY) * (1-fractZ) * noise[(int)x2][(int)y1][(int)z1];
		value += fractX     * fractY     * (1-fractZ) * noise[(int)x2][(int)y2][(int)z1];

		value += (1-fractX) * (1-fractY) * fractZ     * noise[(int)x1][(int)y1][(int)z2];
		value += (1-fractX) * fractY     * fractZ     * noise[(int)x1][(int)y2][(int)z2];
		value += fractX     * (1-fractY) * fractZ     * noise[(int)x2][(int)y1][(int)z2];
		value += fractX     * fractY     * fractZ     * noise[(int)x2][(int)y2][(int)z2];
		
		return value;
	}

	private double turbulence(double x, double y, double z, double size)
	{	double value = 0.0, initialSize = size;
		while(size >= 0.9)
		{	value = value + smoothNoise(x/size, y/size, z/size) * size;
			size = size / 2.0;
		}
		value = 128.0 * value / initialSize;
		return value;
	}

	private double logistic(double x)
	{	double k = 3.0;
		return (1.0/(1.0+Math.pow(2.718,-k*x)));
	}



    private void initGeometryShader(GL4 gl)
    {
        renderingProgram6 = Utils.createShaderProgram("a4/vertShader6.glsl", "a4/geomShader6.glsl", "a4/fragShader6.glsl");        
    }

    private void initNormalMap(GL4 gl)
    {
        renderingProgram7 = Utils.createShaderProgram("a4/vertShader7.glsl", "a4/fragShader7.glsl");
        model3VertexCount = model3.getIndices().length;
        texture4 = Utils.loadTexture("a4/earth.png");
		normalMap = Utils.loadTexture("a4/earthNormal.png");
        int[] indices = model3.getIndices();
		Vector3f[] vertices = model3.getVertices();
		Vector2f[] texCoords = model3.getTexCoords();
		Vector3f[] normals = model3.getNormals();
		Vector3f[] tangents = model3.getTangents();
		
		float[] pvalues = new float[indices.length*3];
		float[] tvalues = new float[indices.length*2];
		float[] nvalues = new float[indices.length*3];
		float[] tanvalues = new float[indices.length*3];

		for (int i=0; i<indices.length; i++)
		{	
            pvalues[i*3]   = (float) (vertices[indices[i]]).x();
			pvalues[i*3+1] = (float) (vertices[indices[i]]).y();
			pvalues[i*3+2] = (float) (vertices[indices[i]]).z();
			tvalues[i*2]   = (float) (texCoords[indices[i]]).x();
			tvalues[i*2+1] = (float) (texCoords[indices[i]]).y();
			nvalues[i*3]   = (float) (normals[indices[i]]).x();
			nvalues[i*3+1] = (float) (normals[indices[i]]).y();
			nvalues[i*3+2] = (float) (normals[indices[i]]).z();
			tanvalues[i*3] = (float) (tangents[indices[i]]).x();
			tanvalues[i*3+1] = (float) (tangents[indices[i]]).y();
			tanvalues[i*3+2] = (float) (tangents[indices[i]]).z();
		}
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
		FloatBuffer vertBuf = Buffers.newDirectFloatBuffer(pvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, vertBuf.limit()*4, vertBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
		FloatBuffer texBuf = Buffers.newDirectFloatBuffer(tvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, texBuf.limit()*4, texBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
		FloatBuffer norBuf = Buffers.newDirectFloatBuffer(nvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, norBuf.limit()*4, norBuf, GL_STATIC_DRAW);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[13]);
		FloatBuffer tanBuf = Buffers.newDirectFloatBuffer(tanvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, tanBuf.limit()*4, tanBuf, GL_STATIC_DRAW);
    }



    public void display(GLAutoDrawable drawable)
    {
        GL4 gl = (GL4)GLContext.getCurrentGL();
        gl.glClearColor(1.0f, 0.5f, 0.5f, 1.0f);
        gl.glClear(GL_COLOR_BUFFER_BIT);
		gl.glClear(GL_DEPTH_BUFFER_BIT);
        Time.update();
        updateCamera();
        updateLight();
        updateScene();
        if(fog == 0f)
        {
            displayCubeMap(gl);
        }
        displayShadowMap(gl);
        if(fog == 0f)
        {
            displayGeometryShader(gl);
        }     
        displayEnvironmentMap(gl);
        displayTransparentObject(gl);
        displayPerlinNoise(gl);
        displayNormalMap(gl);


        //
        gl.glUseProgram(renderingProgram8);
		mvLoc = gl.glGetUniformLocation(renderingProgram8, "mvMat");
		pLoc = gl.glGetUniformLocation(renderingProgram8, "pMat");
		Matrix4f mvMat = new Matrix4f();
        mvMat.mul(camera.getViewMatrix());
		mvMat.translate(this.lightPosition);
		gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(floatBuffer));
		gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));		
		gl.glPointSize(48.0f);
		gl.glDrawArrays(GL_POINTS, 0, 1);
        if(renderGizmo)
        {
            gl.glUseProgram(renderingProgram9);
            mvLoc = gl.glGetUniformLocation(renderingProgram9, "mv_matrix");
            pLoc = gl.glGetUniformLocation(renderingProgram9, "proj_matrix");
            gl.glUniformMatrix4fv(mvLoc, 1, false, camera.getViewMatrix().get(floatBuffer));
            gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));
            gl.glDrawArrays(GL_LINES, 0, 6);
        }    
        // 
    }

    private void updateCamera()
    {
        Vector3f move = new Vector3f();
		if(Input.w) move.z += 1f;
		if(Input.a) move.x -= 1f;
		if(Input.s) move.z -= 1f;
		if(Input.d) move.x += 1f;
		if(Input.q) move.y += 1f;
		if(Input.e) move.y -= 1f;
		move.x *= 10f * Time.delta;
		move.y *= 10f * Time.delta;
		move.z *= 10f * Time.delta;
		camera.translate(move);
		Vector2f rotate = new Vector2f();
		if(Input.up) rotate.y += 1f;
		if(Input.down) rotate.y -= 1f;
		if(Input.left) rotate.x -= 1f;
		if(Input.right) rotate.x += 1f;
		rotate.x *= 90f * Time.delta;
		rotate.y *= 90f * Time.delta;
		camera.pan(rotate.x);
		camera.pitch(rotate.y);
    }
    
    private void updateLight()
    {
        if(control)
        {
            float lightPositionX = (float)Input.mousePositionX / glCanvas.getWidth();
            lightPositionX *= 320f;
            lightPositionX -= 160f;
            float lightPositionZ = (float)Input.mousePositionY / glCanvas.getHeight();
            lightPositionZ *= 320f;
            lightPositionZ -= 160f;
            lightPosition = new Vector3f(lightPositionX, Input.mouseWheelPosition, lightPositionZ);    
        }
        else
        {
            lightPosition = new Vector3f(0f, 12f, 0f);
        }
        lVMat.identity();
        if(lightPosition.x != 0f || lightPosition.z != 0f)
        {
            lVMat.setLookAt(lightPosition, new Vector3f(0f, 0f, 0f), new Vector3f(0f, 1f, 0f));
        }
        else
        {
            Vector4f u = new Vector4f(1f, 0f, 0f, 1f);
            Vector4f v = new Vector4f(0f, 1f, 0f, 1f);
            Vector4f n = new Vector4f(0f, 0f, 1f, 1f);
            Vector4f c = new Vector4f(0f, 0f, 0f, 1f);
            Vector4f vector = new Vector4f();
            v.mul(lightPosition.y, vector);
            vector.w = 0f;
            c.add(vector);
            float radians = (float)Math.toRadians(-90f);
            v.rotateAbout(radians, u.x(), u.y(), u.z());
            n.rotateAbout(radians, u.x(), u.y(), u.z());
            Matrix4f matrix = new Matrix4f();
            Matrix4f r = new Matrix4f(u.x(), v.x(), n.x(), 0f, u.y(), v.y(), n.y(), 0f, u.z(), v.z(), n.z(), 0f, 0f, 0f, 0f, 1f);	
            Matrix4f t = new Matrix4f(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, -c.x(), -c.y(), -c.z(), 1f);
            lVMat = matrix.mul(r).mul(t);
        }
        lPMat.identity();
        lPMat.perspective((float)Math.toRadians(75f), camera.getAspectRatio(), 0.1f, 1000f);
    }

    private void updateScene()
    {
        mMat1.identity();
        mMat1.translate(new Vector3f(0f, 0f, 6f * (float)Math.sin(Math.toRadians(30f * Time.total)) - 2f));
        mMat1.scale(new Vector3f(1.5f, 1.5f, 1.5f));
        mMat2.identity();
        mMat2.translate(new Vector3f(0f, -12f, 0f));
        mMat2.scale(new Vector3f(8f, 8f, 8f));
        mMat2.rotateXYZ(new Vector3f((float)Math.toRadians(Time.total), (float)Math.toRadians(Time.total), (float)Math.toRadians(Time.total)));
        mMat3.identity();
        mMat3.translate(new Vector3f(0f, -24f, 12f * -(float)Math.sin(Math.toRadians(15f * Time.total)) + 6f));
        mMat3.rotateY((float)Math.toRadians(180d));
        mMat3.scale(new Vector3f(1.5f, 1.5f, 1.5f));
    }

    private void displayCubeMap(GL4 gl)
    {
        gl.glUseProgram(renderingProgram0);

        vLoc = gl.glGetUniformLocation(renderingProgram0, "vMat");
        gl.glUniformMatrix4fv(vLoc, 1, false, camera.getViewMatrix().get(floatBuffer));
        pLoc = gl.glGetUniformLocation(renderingProgram0, "pMat");
        gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
        gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_CUBE_MAP, cubeMap);

        gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glDisable(GL_DEPTH_TEST);
		gl.glDrawArrays(GL_TRIANGLES, 0, 36);
		gl.glEnable(GL_DEPTH_TEST);
        gl.glDisable(GL_CULL_FACE);
    }
    
    private void displayShadowMap(GL4 gl)
    {
        gl.glBindFramebuffer(GL_FRAMEBUFFER, shadowBuffer[0]);
        gl.glFramebufferTexture(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, shadowTexture[0], 0);

        gl.glDrawBuffer(GL_NONE);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glEnable(GL_POLYGON_OFFSET_FILL);

        displayShadowMapPass0(gl);

        gl.glDisable(GL_POLYGON_OFFSET_FILL);
		
		gl.glBindFramebuffer(GL_FRAMEBUFFER, 0);
		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, shadowTexture[0]);
	
		gl.glDrawBuffer(GL_FRONT);

        displayShadowMapPass1(gl);
    }
    
    private void displayShadowMapPass0(GL4 gl)
    {
        gl.glUseProgram(renderingProgram1);

        gl.glPolygonOffset(3f, 5f);

        sMVPMat1.identity();
        sMVPMat1.mul(lPMat);
        sMVPMat1.mul(lVMat);
        sMVPMat1.mul(mMat1);
        sLoc = gl.glGetUniformLocation(renderingProgram1, "sMVPMat");
        gl.glUniformMatrix4fv(sLoc, 1, false, sMVPMat1.get(floatBuffer));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

        gl.glClear(GL_DEPTH_BUFFER_BIT);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
      
        gl.glDrawArrays(GL_TRIANGLES, 0, model0.getNumVertices());

        gl.glPolygonOffset(12f, 20f);

        sMVPMat1.identity();
        sMVPMat1.mul(lPMat);
        sMVPMat1.mul(lVMat);
        sMVPMat1.mul(mMat2);
        sLoc = gl.glGetUniformLocation(renderingProgram1, "sMVPMat");
        gl.glUniformMatrix4fv(sLoc, 1, false, sMVPMat1.get(floatBuffer));

		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
      
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
        
        gl.glDrawArrays(GL_TRIANGLES, 0, model1.getNumVertices());

        gl.glPolygonOffset(3f, 5f);

        sMVPMat1.identity();
        sMVPMat1.mul(lPMat);
        sMVPMat1.mul(lVMat);
        sMVPMat1.mul(mMat3);
        sLoc = gl.glGetUniformLocation(renderingProgram1, "sMVPMat");
        gl.glUniformMatrix4fv(sLoc, 1, false, sMVPMat1.get(floatBuffer));

		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
      
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
        
        gl.glDrawArrays(GL_TRIANGLES, 0, model0.getNumVertices());
    }
    
    private void displayShadowMapPass1(GL4 gl)
    {
        gl.glUseProgram(renderingProgram2);

        mvLoc = gl.glGetUniformLocation(renderingProgram2, "mvMat");
		pLoc = gl.glGetUniformLocation(renderingProgram2, "pMat");
		nLoc = gl.glGetUniformLocation(renderingProgram2, "nMat");
		sLoc = gl.glGetUniformLocation(renderingProgram2, "sMVPMat");

        globAmbLoc = gl.glGetUniformLocation(renderingProgram2, "globalAmbient");
		ambLoc = gl.glGetUniformLocation(renderingProgram2, "light.ambient");
		difLoc = gl.glGetUniformLocation(renderingProgram2, "light.diffuse");
		specLoc = gl.glGetUniformLocation(renderingProgram2, "light.specular");
		posLoc = gl.glGetUniformLocation(renderingProgram2, "light.position");
		matAmbLoc = gl.glGetUniformLocation(renderingProgram2, "material.ambient");
		matDifLoc = gl.glGetUniformLocation(renderingProgram2, "material.diffuse");
		matSpecLoc = gl.glGetUniformLocation(renderingProgram2, "material.specular");
		matShiLoc = gl.glGetUniformLocation(renderingProgram2, "material.shininess");

        fLoc = gl.glGetUniformLocation(renderingProgram2, "fog");

        Matrix4fStack matrixStack = new Matrix4fStack(8);
        matrixStack.set(camera.getViewMatrix());

        Vector3f lightPosition = new Vector3f(this.lightPosition.x, this.lightPosition.y, this.lightPosition.z);
        lightPosition.mulPosition(matrixStack);

        gl.glProgramUniform4fv(renderingProgram2, globAmbLoc, 1, globalAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram2, ambLoc, 1, lightAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram2, difLoc, 1, lightDiffuse, 0);
		gl.glProgramUniform4fv(renderingProgram2, specLoc, 1, lightSpecular, 0);
		gl.glProgramUniform3fv(renderingProgram2, posLoc, 1, new float[]{lightPosition.x, lightPosition.y, lightPosition.z}, 0);
		
        gl.glProgramUniform4fv(renderingProgram2, matAmbLoc, 1, materialAmbient1, 0);
		gl.glProgramUniform4fv(renderingProgram2, matDifLoc, 1, materialDiffuse1, 0);
		gl.glProgramUniform4fv(renderingProgram2, matSpecLoc, 1, materialSpecular1, 0);
		gl.glProgramUniform1f(renderingProgram2, matShiLoc, materialShine1);

        gl.glProgramUniform1f(renderingProgram2, fLoc, fog);

        matrixStack.pushMatrix();
        
        matrixStack.mul(mMat1);

        Matrix4f inverseTransposeMatrix = new Matrix4f();
        matrixStack.invert(inverseTransposeMatrix);
        inverseTransposeMatrix.transpose(inverseTransposeMatrix);

        sMVPMat2.identity();
        sMVPMat2.mul(bMat);
        sMVPMat2.mul(lPMat);
        sMVPMat2.mul(lVMat);
        sMVPMat2.mul(mMat1);

        gl.glUniformMatrix4fv(mvLoc, 1, false, matrixStack.get(floatBuffer));
		gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));
		gl.glUniformMatrix4fv(nLoc, 1, false, inverseTransposeMatrix.get(floatBuffer));
		gl.glUniformMatrix4fv(sLoc, 1, false, sMVPMat2.get(floatBuffer));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
        gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(2);
        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(GL_TEXTURE_2D, texture0);
	
		gl.glClear(GL_DEPTH_BUFFER_BIT);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
	
		gl.glDrawArrays(GL_TRIANGLES, 0, model0.getNumVertices());

        matrixStack.popMatrix();

        gl.glProgramUniform4fv(renderingProgram2, matAmbLoc, 1, materialAmbient0, 0);
		gl.glProgramUniform4fv(renderingProgram2, matDifLoc, 1, materialDiffuse0, 0);
		gl.glProgramUniform4fv(renderingProgram2, matSpecLoc, 1, materialSpecular0, 0);
		gl.glProgramUniform1f(renderingProgram2, matShiLoc, materialShine0);

        matrixStack.pushMatrix();
        matrixStack.mul(mMat2);

        inverseTransposeMatrix = new Matrix4f();
        matrixStack.invert(inverseTransposeMatrix);
        inverseTransposeMatrix.transpose(inverseTransposeMatrix);

        sMVPMat2.identity();
        sMVPMat2.mul(bMat);
        sMVPMat2.mul(lPMat);
        sMVPMat2.mul(lVMat);
        sMVPMat2.mul(mMat2);

        gl.glUniformMatrix4fv(mvLoc, 1, false, matrixStack.get(floatBuffer));
		gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));
		gl.glUniformMatrix4fv(nLoc, 1, false, inverseTransposeMatrix.get(floatBuffer));
		gl.glUniformMatrix4fv(sLoc, 1, false, sMVPMat2.get(floatBuffer));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);	

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
        gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(2);
        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(GL_TEXTURE_2D, texture1);

		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
	
		gl.glDrawArrays(GL_TRIANGLES, 0, model1.getNumVertices());

        matrixStack.popMatrix();

        gl.glProgramUniform4fv(renderingProgram2, matAmbLoc, 1, materialAmbient0, 0);
		gl.glProgramUniform4fv(renderingProgram2, matDifLoc, 1, materialDiffuse0, 0);
		gl.glProgramUniform4fv(renderingProgram2, matSpecLoc, 1, materialSpecular0, 0);
		gl.glProgramUniform1f(renderingProgram2, matShiLoc, materialShine0);

        matrixStack.pushMatrix();
        matrixStack.mul(mMat3);

        inverseTransposeMatrix = new Matrix4f();
        matrixStack.invert(inverseTransposeMatrix);
        inverseTransposeMatrix.transpose(inverseTransposeMatrix);

        sMVPMat2.identity();
        sMVPMat2.mul(bMat);
        sMVPMat2.mul(lPMat);
        sMVPMat2.mul(lVMat);
        sMVPMat2.mul(mMat3);

        gl.glUniformMatrix4fv(mvLoc, 1, false, matrixStack.get(floatBuffer));
		gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));
		gl.glUniformMatrix4fv(nLoc, 1, false, inverseTransposeMatrix.get(floatBuffer));
		gl.glUniformMatrix4fv(sLoc, 1, false, sMVPMat2.get(floatBuffer));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);


		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);	

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
        gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(2);
        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(GL_TEXTURE_2D, texture0);

		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
	
		gl.glDrawArrays(GL_TRIANGLES, 0, model0.getNumVertices());

        matrixStack.popMatrix();
    }

    private void displayTransparentObject(GL4 gl)
    {
        gl.glUseProgram(renderingProgram3);

        mvLoc = gl.glGetUniformLocation(renderingProgram3, "mvMat");
		pLoc = gl.glGetUniformLocation(renderingProgram3, "pMat");
		nLoc = gl.glGetUniformLocation(renderingProgram3, "nMat");

        globAmbLoc = gl.glGetUniformLocation(renderingProgram3, "globalAmbient");
		ambLoc = gl.glGetUniformLocation(renderingProgram3, "light.ambient");
		difLoc = gl.glGetUniformLocation(renderingProgram3, "light.diffuse");
		specLoc = gl.glGetUniformLocation(renderingProgram3, "light.specular");
		posLoc = gl.glGetUniformLocation(renderingProgram3, "light.position");
		matAmbLoc = gl.glGetUniformLocation(renderingProgram3, "material.ambient");
		matDifLoc = gl.glGetUniformLocation(renderingProgram3, "material.diffuse");
		matSpecLoc = gl.glGetUniformLocation(renderingProgram3, "material.specular");
		matShiLoc = gl.glGetUniformLocation(renderingProgram3, "material.shininess");

        fLoc = gl.glGetUniformLocation(renderingProgram3, "fog");

        alphaLoc = gl.glGetUniformLocation(renderingProgram3, "alpha");
		flipLoc = gl.glGetUniformLocation(renderingProgram3, "flipNormal");

        mMat4 = new Matrix4f();
        mMat4.translate(-24f, -12f, 6f);
        Matrix4f mvMat = camera.getViewMatrix().mul(mMat4);
        Matrix4f invTrMat = new Matrix4f();
        mvMat.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glProgramUniform4fv(renderingProgram3, globAmbLoc, 1, globalAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram3, ambLoc, 1, lightAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram3, difLoc, 1, lightDiffuse, 0);
		gl.glProgramUniform4fv(renderingProgram3, specLoc, 1, lightSpecular, 0);
		gl.glProgramUniform3fv(renderingProgram3, posLoc, 1, new float[]{lightPosition.x, lightPosition.y, lightPosition.z}, 0);
		
        gl.glProgramUniform4fv(renderingProgram3, matAmbLoc, 1, materialAmbient1, 0);
		gl.glProgramUniform4fv(renderingProgram3, matDifLoc, 1, materialDiffuse1, 0);
		gl.glProgramUniform4fv(renderingProgram3, matSpecLoc, 1, materialSpecular1, 0);
		gl.glProgramUniform1f(renderingProgram3, matShiLoc, materialShine1);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(floatBuffer));
		gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(floatBuffer));
        gl.glProgramUniform1f(renderingProgram3, fLoc, fog);

        gl.glProgramUniform1f(renderingProgram3, alphaLoc, 1.0f);
		gl.glProgramUniform1f(renderingProgram3, flipLoc, 1.0f);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
        gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(2);
        gl.glBindTexture(GL_TEXTURE_2D, texture0);

        gl.glEnable(GL_BLEND);
		gl.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		gl.glBlendEquation(GL_FUNC_ADD);

		gl.glEnable(GL_CULL_FACE);

        float alphaFactor = (float)Math.abs(Math.sin(Math.toRadians((45f * Time.total) % 180f)));
		
		gl.glCullFace(GL_FRONT);
		gl.glProgramUniform1f(renderingProgram3, alphaLoc, 0.5f * alphaFactor);
		gl.glProgramUniform1f(renderingProgram3, flipLoc, -1.0f);
		gl.glDrawArrays(GL_TRIANGLES, 0, model0.getNumVertices());
		
		gl.glCullFace(GL_BACK);
		gl.glProgramUniform1f(renderingProgram3, alphaLoc, 1.0f * alphaFactor);
		gl.glProgramUniform1f(renderingProgram3, flipLoc, 1.0f);
		gl.glDrawArrays(GL_TRIANGLES, 0, model0.getNumVertices());

        alphaFactor = (float)Math.abs(Math.sin(Math.toRadians((45f * Time.total + 90f) % 180f)));
		
        mMat5 = new Matrix4f();
        mMat5.translate(-24f, -12f, -6f);
        mMat5.rotateY((float)Math.toRadians(180f));
        mvMat = camera.getViewMatrix().mul(mMat5);
        invTrMat = new Matrix4f();
        mvMat.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(floatBuffer));
		gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(floatBuffer));

		gl.glCullFace(GL_FRONT);
		gl.glProgramUniform1f(renderingProgram3, alphaLoc, 0.5f * alphaFactor);
		gl.glProgramUniform1f(renderingProgram3, flipLoc, -1.0f);
		gl.glDrawArrays(GL_TRIANGLES, 0, model0.getNumVertices());
		
		gl.glCullFace(GL_BACK);
		gl.glProgramUniform1f(renderingProgram3, alphaLoc, 1.0f * alphaFactor);
		gl.glProgramUniform1f(renderingProgram3, flipLoc, 1.0f);
		gl.glDrawArrays(GL_TRIANGLES, 0, model0.getNumVertices());

		gl.glDisable(GL_BLEND);
    }

    private void displayPerlinNoise(GL4 gl)
    {
        gl.glUseProgram(renderingProgram4);

        mvLoc = gl.glGetUniformLocation(renderingProgram4, "mvMat");
		pLoc = gl.glGetUniformLocation(renderingProgram4, "pMat");
		nLoc = gl.glGetUniformLocation(renderingProgram4, "nMat");
		sLoc = gl.glGetUniformLocation(renderingProgram4, "sMVPMat");

        fLoc = gl.glGetUniformLocation(renderingProgram4, "fog");

        globAmbLoc = gl.glGetUniformLocation(renderingProgram4, "globalAmbient");
		ambLoc = gl.glGetUniformLocation(renderingProgram4, "light.ambient");
		difLoc = gl.glGetUniformLocation(renderingProgram4, "light.diffuse");
		specLoc = gl.glGetUniformLocation(renderingProgram4, "light.specular");
		posLoc = gl.glGetUniformLocation(renderingProgram4, "light.position");
		matAmbLoc = gl.glGetUniformLocation(renderingProgram4, "material.ambient");
		matDifLoc = gl.glGetUniformLocation(renderingProgram4, "material.diffuse");
		matSpecLoc = gl.glGetUniformLocation(renderingProgram4, "material.specular");
		matShiLoc = gl.glGetUniformLocation(renderingProgram4, "material.shininess");

        Matrix4f mMat = new Matrix4f();
        mMat.translate(10f, 10f, -12f);
        mMat.scale(8f);

        Matrix4f mvMat = camera.getViewMatrix().mul(mMat);
        Matrix4f invTrMat = new Matrix4f();
        mvMat.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(floatBuffer));
		gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(floatBuffer));

        gl.glProgramUniform4fv(renderingProgram4, globAmbLoc, 1, globalAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram4, ambLoc, 1, lightAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram4, difLoc, 1, lightDiffuse, 0);
		gl.glProgramUniform4fv(renderingProgram4, specLoc, 1, lightSpecular, 0);
		gl.glProgramUniform3fv(renderingProgram4, posLoc, 1, new float[]{lightPosition.x, lightPosition.y, lightPosition.z}, 0);
		
        gl.glProgramUniform4fv(renderingProgram4, matAmbLoc, 1, new float[]{1f, 0f, 0f, 1f}, 0);
		gl.glProgramUniform4fv(renderingProgram4, matDifLoc, 1,  materialDiffuse1, 0);
		gl.glProgramUniform4fv(renderingProgram4, matSpecLoc, 1, materialSpecular1, 0);
		gl.glProgramUniform1f(renderingProgram4, matShiLoc, materialShine1);

        gl.glProgramUniform1f(renderingProgram4, fLoc, fog);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_3D, noiseTexture);
		
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

		gl.glDrawArrays(GL_TRIANGLES, 0, model1.getNumVertices());
    }

    private void displayEnvironmentMap(GL4 gl)
    {
        gl.glUseProgram(renderingProgram5);
        mvLoc = gl.glGetUniformLocation(renderingProgram5, "mvMat");
		pLoc = gl.glGetUniformLocation(renderingProgram5, "pMat");
		nLoc = gl.glGetUniformLocation(renderingProgram5, "nMat"); 
        fLoc = gl.glGetUniformLocation(renderingProgram5, "fog");
        Matrix4f mMat = new Matrix4f();
        mMat.translate(32f, 0f, 32f);
        mMat.rotateX((float)Math.toRadians(-90f));
        mMat.scale(8f);
        Matrix4f mvMat = camera.getViewMatrix().mul(mMat);
        Matrix4f invTrMat = new Matrix4f();
        mvMat.invert(invTrMat);
		invTrMat.transpose(invTrMat);
        gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(floatBuffer));
		gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(floatBuffer));
        gl.glProgramUniform1f(renderingProgram5, fLoc, fog);
        

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[7]);
        gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

        gl.glActiveTexture(GL_TEXTURE1);
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
        gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(1);
        gl.glBindTexture(GL_TEXTURE_2D, texture2);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
		gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);

		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_CUBE_MAP, cubeMap);
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glDepthFunc(GL_LEQUAL);

        gl.glDrawArrays(GL_TRIANGLES, 0, model2.getNumVertices());
    }

    private void displayGeometryShader(GL4 gl)
    {
        gl.glUseProgram(renderingProgram6);
     
        globAmbLoc = gl.glGetUniformLocation(renderingProgram6, "globalAmbient");
		ambLoc = gl.glGetUniformLocation(renderingProgram6, "light.ambient");
		difLoc = gl.glGetUniformLocation(renderingProgram6, "light.diffuse");
		specLoc = gl.glGetUniformLocation(renderingProgram6, "light.specular");
		posLoc = gl.glGetUniformLocation(renderingProgram6, "light.position");
		matAmbLoc = gl.glGetUniformLocation(renderingProgram6, "material.ambient");
		matDifLoc = gl.glGetUniformLocation(renderingProgram6, "material.diffuse");
		matSpecLoc = gl.glGetUniformLocation(renderingProgram6, "material.specular");
		matShiLoc = gl.glGetUniformLocation(renderingProgram6, "material.shininess");

        mvLoc = gl.glGetUniformLocation(renderingProgram6, "mvMat");
		pLoc = gl.glGetUniformLocation(renderingProgram6, "pMat");
		nLoc = gl.glGetUniformLocation(renderingProgram6, "nMat"); 
        fLoc = gl.glGetUniformLocation(renderingProgram6, "fog");
        int eLoc = gl.glGetUniformLocation(renderingProgram6, "explosion");

        Matrix4f mMat = new Matrix4f();
        mMat.translate(-20f, -20f, -20f);
        mMat.rotateX((float)Math.toRadians(-90f));
        mMat.scale(4f);
        Matrix4f mvMat = camera.getViewMatrix().mul(mMat);
        Matrix4f invTrMat = new Matrix4f();
        mvMat.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(floatBuffer));
		gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(floatBuffer));

        int enableLightingLoc = gl.glGetUniformLocation(renderingProgram6, "enableLighting");

        gl.glProgramUniform4fv(renderingProgram6, globAmbLoc, 1, globalAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram6, ambLoc, 1, lightAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram6, difLoc, 1, lightDiffuse, 0);
		gl.glProgramUniform4fv(renderingProgram6, specLoc, 1, lightSpecular, 0);
		gl.glProgramUniform3fv(renderingProgram6, posLoc, 1, new float[]{lightPosition.x, lightPosition.y, lightPosition.z}, 0);
		
        gl.glProgramUniform4fv(renderingProgram6, matAmbLoc, 1, materialAmbient1, 0);
		gl.glProgramUniform4fv(renderingProgram6, matDifLoc, 1, materialDiffuse1, 0);
		gl.glProgramUniform4fv(renderingProgram6, matSpecLoc, 1, materialSpecular1, 0);
		gl.glProgramUniform1f(renderingProgram6, matShiLoc, materialShine1);

        gl.glProgramUniform1f(renderingProgram6, fLoc, fog);
        float factor = (float)Math.sin(Math.toRadians(45f * Time.total));
        if(factor < 0f) factor = 0f;
        else factor *= 15f;
        gl.glProgramUniform1f(renderingProgram6, eLoc, factor);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[7]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
        gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(1);
        gl.glBindTexture(GL_TEXTURE_2D, texture2);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
		gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);

        gl.glEnable(GL_CULL_FACE);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

        gl.glUniform1i(enableLightingLoc,1);
        gl.glFrontFace(GL_CCW);
        gl.glDrawArrays(GL_TRIANGLES, 0, model2.getNumVertices());
        
        gl.glUniform1i(enableLightingLoc,0);
        gl.glFrontFace(GL_CW);
        gl.glDrawArrays(GL_TRIANGLES, 0, model2.getNumVertices());

        gl.glFrontFace(GL_CCW);
    }

    private void displayNormalMap(GL4 gl)
    {
        gl.glUseProgram(renderingProgram7);

        mvLoc = gl.glGetUniformLocation(renderingProgram7, "mvMat");
		pLoc = gl.glGetUniformLocation(renderingProgram7, "pMat");
		nLoc = gl.glGetUniformLocation(renderingProgram7, "nMat");

        globAmbLoc = gl.glGetUniformLocation(renderingProgram7, "globalAmbient");
		ambLoc = gl.glGetUniformLocation(renderingProgram7, "light.ambient");
		difLoc = gl.glGetUniformLocation(renderingProgram7, "light.diffuse");
		specLoc = gl.glGetUniformLocation(renderingProgram7, "light.specular");
		posLoc = gl.glGetUniformLocation(renderingProgram7, "light.position");
		matAmbLoc = gl.glGetUniformLocation(renderingProgram7, "material.ambient");
		matDifLoc = gl.glGetUniformLocation(renderingProgram7, "material.diffuse");
		matSpecLoc = gl.glGetUniformLocation(renderingProgram7, "material.specular");
		matShiLoc = gl.glGetUniformLocation(renderingProgram7, "material.shininess");

        fLoc = gl.glGetUniformLocation(renderingProgram7, "fog");

        Matrix4f mMat = new Matrix4f();
        mMat.translate(200f, 0f, 0);
        mMat.rotateY((float)Math.toRadians(10f * Time.total));
        mMat.scale(20f);
        Matrix4f mvMat = camera.getViewMatrix().mul(mMat);
        Matrix4f invTrMat = new Matrix4f();
        mvMat.invert(invTrMat);
		invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(floatBuffer));
		gl.glUniformMatrix4fv(pLoc, 1, false, camera.getPerspectiveMatrix().get(floatBuffer));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(floatBuffer));
        gl.glProgramUniform1f(renderingProgram7, fLoc, fog);

        gl.glProgramUniform4fv(renderingProgram7, globAmbLoc, 1, globalAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram7, ambLoc, 1, lightAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram7, difLoc, 1, lightDiffuse, 0);
		gl.glProgramUniform4fv(renderingProgram7, specLoc, 1, lightSpecular, 0);
		gl.glProgramUniform3fv(renderingProgram7, posLoc, 1, new float[]{lightPosition.x, lightPosition.y, lightPosition.z}, 0);
		
        gl.glProgramUniform4fv(renderingProgram7, matAmbLoc, 1, materialAmbient1, 0);
		gl.glProgramUniform4fv(renderingProgram7, matDifLoc, 1, materialDiffuse1, 0);
		gl.glProgramUniform4fv(renderingProgram7, matSpecLoc, 1, materialSpecular1, 0);
		gl.glProgramUniform1f(renderingProgram7, matShiLoc, materialShine1);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
		gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[13]);
		gl.glVertexAttribPointer(3, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(3);
		
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, normalMap);
		
		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, texture4);

		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

		gl.glDrawArrays(GL_TRIANGLES, 0, model3VertexCount);
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height)
	{
		camera.setAspectRatio(glCanvas.getWidth(), glCanvas.getHeight());
	}
    
    public void dispose(GLAutoDrawable drawable){}

    //====================================================================================================
	// KeyListener Implementation
	//====================================================================================================	
	public void keyPressed(KeyEvent e)
	{
        switch(e.getKeyCode())
		{
			case KeyEvent.VK_W:
				Input.w = true;
				break;
			case KeyEvent.VK_A:
				Input.a = true;
				break;
			case KeyEvent.VK_S:
				Input.s = true;
				break;
			case KeyEvent.VK_D:
				Input.d = true;
				break;
			case KeyEvent.VK_Q:
				Input.q = true;
				break;
			case KeyEvent.VK_E:
				Input.e = true;
				break;
			case KeyEvent.VK_UP:
				Input.up = true;
				break;
			case KeyEvent.VK_DOWN:
				Input.down = true;
				break;
			case KeyEvent.VK_LEFT:
				Input.left = true;
				break;
			case KeyEvent.VK_RIGHT:
				Input.right = true;
				break;
            case KeyEvent.VK_F:
                if(fog == 0f)
                {
                    fog = 1f;
                }
                else
                {
                    fog = 0f;
                }
                break;
            case KeyEvent.VK_G:
                renderGizmo = !renderGizmo;
                break;
            case KeyEvent.VK_L:
                if(!lightSwitch)
                {
                    lightAmbient = new float[] { 0.0f, 0.0f, 0.0f, 1.0f };
                    lightDiffuse = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
                    lightSpecular = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
                    lightSwitch = true;
                }
                else
                {
                    lightAmbient = new float[] { 0.0f, 0.0f, 0.0f, 1.0f };
                    lightDiffuse = new float[] { 0.0f, 0.0f, 0.0f, 1.0f };
                    lightSpecular = new float[] { 0.0f, 0.0f, 0.0f, 1.0f };
                    lightSwitch = false;
                }
                break;
            case KeyEvent.VK_C:
                control = !control;
                break;
        }
	}
	
	public void keyReleased(KeyEvent e)
	{
        switch(e.getKeyCode())
		{
			case KeyEvent.VK_W:
				Input.w = false;
				break;
			case KeyEvent.VK_A:
				Input.a = false;
				break;
			case KeyEvent.VK_S:
				Input.s = false;
				break;
			case KeyEvent.VK_D:
				Input.d = false;
				break;
			case KeyEvent.VK_Q:
				Input.q = false;
				break;
			case KeyEvent.VK_E:
				Input.e = false;
				break;
			case KeyEvent.VK_UP:
				Input.up = false;
				break;
			case KeyEvent.VK_DOWN:
				Input.down = false;
				break;
			case KeyEvent.VK_LEFT:
				Input.left = false;
				break;
			case KeyEvent.VK_RIGHT:
				Input.right = false;
				break;
        }
	}
	
	public void keyTyped(KeyEvent e){}

	//====================================================================================================
	// MouseMotionListener Implementation
	//====================================================================================================
	public void mouseDragged(MouseEvent e){}

	public void mouseMoved(MouseEvent e)
	{
        Input.mousePositionX = e.getX();
		Input.mousePositionY = e.getY();
	}

    //====================================================================================================
	// MouseWheelMoved
    //====================================================================================================
	public void mouseWheelMoved(MouseWheelEvent e)
	{
        int scrollAmount = e.getWheelRotation();
		int totalScrollAmount = Input.mouseWheelPosition - scrollAmount;
		if(totalScrollAmount > 64) totalScrollAmount = 64;
		else if (totalScrollAmount < -64) totalScrollAmount = -64;
		Input.mouseWheelPosition = totalScrollAmount;
	}

    //====================================================================================================
	// WindowFocusListener Implementation
	//====================================================================================================
	public void windowGainedFocus(WindowEvent e){}
	
	public void windowLostFocus(WindowEvent e)
    {
        Input.reset();
    }

    //====================================================================================================
    // Constructor
    //====================================================================================================
    public Starter()
    {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Zachary Wagner");
		setSize(1280, 720);
        setResizable(false);

        glCanvas = new GLCanvas();
        glCanvas.addGLEventListener(this);
        this.add(glCanvas);
		this.setVisible(true);

		addWindowFocusListener(this);

		glCanvas.addKeyListener(this);
		glCanvas.addMouseMotionListener(this);
		glCanvas.addMouseWheelListener(this);

        Animator animator = new Animator(glCanvas);
		animator.start(); 

        glCanvas.requestFocus();

        bMat.set(
			0.5f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.5f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.5f, 0.0f,
			0.5f, 0.5f, 0.5f, 1.0f);

        Input.mouseWheelPosition = 12;
    }

    //====================================================================================================
    // Main
    //====================================================================================================
    public static void main(String[] args) 
    {
        new Starter();
    }
}
//#endregion
