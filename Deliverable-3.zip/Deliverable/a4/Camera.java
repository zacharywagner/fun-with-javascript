package a4;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

public class Camera 
{
    private Vector4f u = new Vector4f(1f, 0f, 0f, 1f);
    private Vector4f v = new Vector4f(0f, 1f, 0f, 1f);
    private Vector4f n = new Vector4f(0f, 0f, 1f, 1f);
    private Vector4f c = new Vector4f(0f, 0f, 0f, 1f);

    private Matrix4f pMat = new Matrix4f();

    private float aspectRatio;

    public Camera(Vector3f position, float pan, float pitch)
    {
        translate(position);
        pan(pan);
        pitch(pitch);
    }
    
    public Matrix4f getPerspectiveMatrix()
    {
        return pMat;
    }

    public Matrix4f getViewMatrix()
    {
        Matrix4f matrix = new Matrix4f();
        Matrix4f r = new Matrix4f(u.x(), v.x(), n.x(), 0f, u.y(), v.y(), n.y(), 0f, u.z(), v.z(), n.z(), 0f, 0f, 0f, 0f, 1f);	
        Matrix4f t = new Matrix4f(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, -c.x(), -c.y(), -c.z(), 1f);
        return matrix.mul(r).mul(t);
    }

    public float getAspectRatio()
    {
        return aspectRatio;
    }

    public void setAspectRatio(int width, int height)
    {
        aspectRatio = (float)width / (float)height;
        pMat.setPerspective((float) Math.toRadians(60.0f), aspectRatio, 0.1f, 1000.0f);
    }
    
    public void translate(Vector3f translation)
    {		
        Vector4f vector = new Vector4f();
        translation.z *= -1f;
        n.mul(translation.z, vector);
        vector.w = 0f;
        c.add(vector);
        vector = new Vector4f();
        u.mul(translation.x, vector);
        vector.w = 0f;
        c.add(vector);
        vector = new Vector4f();
        v.mul(translation.y, vector);
        vector.w = 0f;
        c.add(vector);
    }
    
    public void pan(float degrees)
    {
        degrees *= -1f;
        float radians = (float)Math.toRadians(degrees);
        u.rotateAbout(radians, v.x(), v.y(), v.z());
        n.rotateAbout(radians, v.x(), v.y(), v.z());
    }
    
    public void pitch(float degrees)
    {
        float radians = (float)Math.toRadians(degrees);
        v.rotateAbout(radians, u.x(), u.y(), u.z());
        n.rotateAbout(radians, u.x(), u.y(), u.z());
    }    
}
